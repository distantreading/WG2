The nanobrown: a Brown corpus source archive sample
===================================================
Copyright (c) 2015 Serge Heiden, ENS de Lyon
Copyright (c) 1964 Department of Linguistics, Brown University Providence, Rhode Island, USA. Revised 1971, Revised and Amplified 1979
CC BY-SA licence

The nanobrown corpus is a nano sample of the original "Standard Corpus of Present-Day Edited American English, for use with Digital Computers." by W. N. Francis and H. Kucera (1964). See https://sourceforge.net/projects/txm/files/corpora/brown

It is composed of 6 texts:
- 3 texts of type 'PRESS: REPORTAGE'
 - a01	Sample A01 from The Atlanta Constitution
 - a02	Sample A02 from The Dallas Morning News, February 17,1961,section 1
 - a03	Sample A03 from Chicago Daily Tribune
- 3 texts are of type 'FICTION: ADVENTURE'
 - n01	Sample N01 from Wayne D. Overholser, The Killer Marshal. New York: Dell Publishing Co., 1963.
 - n02	Sample N02 from Clifford Irving, The Valley. New York: McGraw-Hill Book Company, Inc., 1961. Pp. 262-267.
 - n03	Sample N03 from Cliff Farrell, Trail of the Tattered Star. Garden City
        New York: Doubleday and Company, Inc., 1961. Pp. 168-173.

Those 6 texts are provided in two different formats:
- the 'nanobrown-txt' TXT directory contains text sources in Unicode raw text format
- the 'nanobrown-xml' XML directory contains text sources in basic XML format

The 'nanobrown-metadata' directory contains texts metadata in three different formats:
- metadata.csv in *CSV* format (column separator is comma ',' and text fields are delimited by ")
- metadata.ods in LibreOffice *Calc* format
- metadata.xls in Microsoft Office *Excel* format
The first file is to be used with TXM.

The nanobrown corpus is designed to be used for learning how to import corpora sources
into TXM. The small size of the corpus alows fast multiple imports of the same sources
at different levels of encoding. And texts contain the basic features needed to be fully
exploited by TXM :
- texts and their metadata
- internal structures and their properties
- words and their properties

Typical pedagogical progression: adaptative digital philology
-------------------------------------------------------------

The import process is teached by importing successivly the same sources at different
levels of representation or information encoding: from bare character sequences in raw text
format to fully structured, metadata informed and word encoded XML format.
Each new import stage introduces a new information element to encode in text sources and
then to exploit into TXM, showing how the user can decide the type and level of information
to encode in text sources depending on the services he wants to get from TXM and his sources
with respect to the encoding cost.
XML-TEI encoding and import into TXM is presented in a next lesson.

0. Clipboard source
 - open the 'nanobrown-txt/a01.txt' text file in a word processor or text editor
 - select and copy the text
 - set Clipboard language preference parameter (for automatic tagging)
 - Clipboard import
 - build the lexicon, double-clic on a word for concordance, double-clic on a line for
   text edition access with word highlight
 - verify the text in the edition
 - show word properties in the edition

1. TXT sources
 - TXT+CSV import nanobrown-txt with EN language model (keep import parameters form open)
 - explain corpus Description with TreeTagger word properties
 - show word, enlemma & enpos lexicons
 - show TreeTagger POS tagset
 - use text identity from file: show partition or sub-corpus based on text ids

2. TXT sources and metadata
 - copy metadata.csv to nanobrown-txt
 - TXT+CSV re-import nanobrown-txt (use same import parameters form)
 - explain corpus Description with metadata
 - show partition or sub-corpus based on text 'type' metadata and explain difference with text identity contrast
 * adding metadata
 - add a new metadata column in metadata.csv
 - TXT+CSV re-import nanobrown-txt (use same import parameters form)
 - explain corpus Description with new metadata
 - show partition or sub-corpus based on new text metadata

3. XML sources and structures
 - XML+CSV import nanobrown-xml with EN language model (keep import parameters form open)
 (you can copy the same metadata.csv file to the nanobrown-xml directory but it will not be used in the exercices)
 - show that the corpus is the same
 - explain corpus Description with structures
 * structure
 - open 'a01.xml' file in TXM text editor (File / Open...)
 - in a01.xml show basic text structure <p>
 - show a concordance of first words of <p>s and go to text edition for the first hit to see the paragraph
 - in a01.xml show two <p>s with type @attribute
 - show a concordance of first word of the first paragraph and go to text edition to verify
 - build the sub-corpus of text a01
 - build the sub-corpus of the first paragraph of text a01
 - build lexicon of that sub-corpus

4. XML sources + new structure
 * adding structure
 - add an XML structure of your choice in 'a01.xml', you can repeat the structure
 - XML+CSV re-import nanobrown-xml (use same import parameters form)
 - explain corpus Description with new structure
 - do a search and edition or sub-corpus build that uses the new structure
 * adding structure property
 - add a property to the XML structure of your choice in 'a01.xml', you can encode different values for that attribute/property
 - XML+CSV re-import nanobrown-xml (use same import parameters form)
 - explain corpus Description with new structure property
 - do a search and edition or sub-corpus build that uses the new structure property
 * filtering a structure
 - in import parameters form, add a call to a front XSL filter: xsl-filter-p to filter out the first paragraph
 - XML+CSV re-import nanobrown-xml
 - verify that the structures content has disapeared

5. XML sources and words
 * words
 - in a01.xml show "Fulton County Grand Jury" word
 - do the concordance of words begining with "Fulton" and go to the text for "Fulton County Grand Jury"
 - do the Index of words containing blank [word=".* .*"]
 - in a01.xml show "City of Atlanta" word of type "place"
 - do the concordance of words of type "place"
 * adding word encoding
 - in a01.xml add a new coumpound word with <w>
 - XML+CSV re-import nanobrown-xml (use same import parameters form)
 - do the concordance of words begining like the coumpouned word and go to the text to verify the word highlight
 * adding word property
 - in a01.xml add a new property to an encoded word (with <w>)
 - XML+CSV re-import nanobrown-xml (use same import parameters form)
 - explain corpus Description with new word property
 - do the concordance of words having the new property to a choosen value and go to the text to verify the word highlight


Power Tools for source encoding
-------------------------------

- search/replace
- search/replace of reg exp
- search/replace of reg exp with match reuse
- batch search/replace in all files in a directory
- xmlstatistics uniq XML paths
- xmldiagnostic of some encodings through XPATH extraction
 - number of pb
 - page number of last page
 - number of lines
 - list and number of locutors
 - list and number of different chapters
 - etc.
- xmldiagnostic of maps of some encodings through XPATH extraction
 - parts / chapters hierarchical map
 - parts / chapters / page number map
- xmldiagnostic of patterns of some encodings through XPATH extraction
 - looking for holes - page numbers: I I II 1 2 3 4 5
 - looking for patterns - turn locutors alternance: S O S O T S O S U S O
- batch converting TXT to XML
- etc.

