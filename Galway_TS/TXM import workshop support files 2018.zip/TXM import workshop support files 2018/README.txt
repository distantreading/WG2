Support files for TXM workshop, Serge Heiden, 2015:
- Brown Penn Treebank Tagset: the definition of every morpho-syntactic
  tag used in the Brown corpus;
- nanobrown: a very small subset of the Brown corpus source files;
- txm import process: slides to introduce to the TXM import environment;
- readme: this file.

